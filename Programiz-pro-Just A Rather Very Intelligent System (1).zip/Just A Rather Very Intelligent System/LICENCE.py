
##License
##This project is not licensed. You cannot use,    
##modify, or distribute the code without explicit 
##permission from the author.
