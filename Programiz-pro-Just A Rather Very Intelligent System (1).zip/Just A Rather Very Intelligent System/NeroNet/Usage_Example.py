import NeroNet

# Example Usage

network = [
    ['input', 2],     #Network input
    ['hidden1', 3],   #Network hiddenlayer_1
    ['hidden2', 5],   #Network hiddenlayer_1
    ['output', 1]     #Network output
]

samples = [ #Traning Data: ([In_1, In_2], [Out])
    ([0, 0], [0]),
    ([0, .5], [.5]),
    ([.5, 0], [.5]),
    ([.5, .5], [1]),
]

nn = NeuralNetwork(network)

#Traning setup
nn.add_training_data(samples)
nn.train(epochs=48000, learning_rate=0.01)

#Output text via console
predictions = nn.predict(nn.X)
print("\nFinal predictions:")
print(predictions)

#Show averages
nn.show_layer_averages()
