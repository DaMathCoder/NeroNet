from setuptools import setup, find_packages

setup(
    name="NeroNet",
    version="3.0.0",
    packages=find_packages(),
    install_requires=[],
    author="Landen M. Martin",
    author_email="lmartin@aplusup.org",
    description="A simple easy to use Nero Network builder that's fully customizable",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/NeroNet",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)